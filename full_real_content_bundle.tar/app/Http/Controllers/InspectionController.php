<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inspection;

class InspectionController extends Controller
{
    public function publicView($uuid) {
        $inspection = Inspection::with('sections.findings')->findOrFail($uuid);
        return view('inspections.public', compact('inspection'));
    }
}
