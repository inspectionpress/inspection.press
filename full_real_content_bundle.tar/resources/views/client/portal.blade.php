@extends('layouts.app')
@section('content')
<div class="p-6">
  <h1 class="text-xl font-bold">Client Portal</h1>
  <ul>
    <li><a href="#">View Inspection Report</a></li>
    <li><a href="#">Download Four Point PDF</a></li>
    <li><a href="#">Download Wind Mit PDF</a></li>
  </ul>
</div>
@endsection
