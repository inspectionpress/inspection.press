@extends('layouts.app')
@section('content')
<div class="p-6">
  <h1 class="text-xl font-bold">Inspection Report</h1>
  <p>This will display the full inspection data with sections and findings.</p>
</div>
@endsection
