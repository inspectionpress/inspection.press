<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inspection;
use App\Models\Customer;
use PDF;

class InspectionController extends Controller
{
    public function create()
    {
        $customers = Customer::all();
        return view('inspections.create', compact('customers'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'property_address' => 'required|string',
            'inspection_date' => 'required|date',
            'name' => 'required_without:customer_id|string',
            'email' => 'nullable|email',
            'phone' => 'nullable|string',
            'address' => 'nullable|string',
        ]);

        // Determine if new or existing customer
        if ($request->filled('customer_id')) {
            $customer_id = $request->customer_id;
        } else {
            $customer = Customer::create([
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'address' => $request->address,
            ]);
            $customer_id = $customer->id;
        }

        $inspection = Inspection::create([
            'customer_id' => $customer_id,
            'property_address' => $request->property_address,
            'inspection_date' => $request->inspection_date,
        ]);

        return redirect()->route('inspection.show', $inspection->id);
    }

    public function publicView($uuid)
    {
        $inspection = Inspection::with('sections.findings')->findOrFail($uuid);
        return view('inspections.public', compact('inspection'));
    }

    public function downloadPdf($uuid)
    {
        $inspection = Inspection::with('sections.findings')->findOrFail($uuid);
        $pdf = PDF::loadView('inspections.public-pdf', compact('inspection'));
        return $pdf->download('inspection-report-' . $inspection->id . '.pdf');
    }
}
